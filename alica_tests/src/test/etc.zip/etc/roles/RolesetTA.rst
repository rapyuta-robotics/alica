{
  "id" : 1410440904638,
  "name" : "RolesetTA",
  "comment" : "",
  "relativeDirectory" : "",
  "defaultPriority" : 0.5,
  "defaultRoleSet" : true,
  "roles" : [ {
    "id" : 1222973291111,
    "name" : "Attacker",
    "comment" : "",
    "taskPriorities" : {
      "taskrepository.tsk#1407153522080" : 0.6,
      "taskrepository.tsk#1407153536219" : 0.5,
      "taskrepository.tsk#1225112227903" : 0.5,
      "taskrepository.tsk#1402488486725" : 0.5
    },
    "characteristics" : [ ],
    "roleSet" : 1410440904638
  }, {
    "id" : 1222973292222,
    "name" : "Defender",
    "comment" : "",
    "taskPriorities" : {
      "taskrepository.tsk#1625610785404" : 0.0,
      "taskrepository.tsk#1625610762033" : 1.0
    },
    "characteristics" : [ ],
    "roleSet" : 1410440904638
  }, {
    "id" : 1222973293333,
    "name" : "DefendSupporter",
    "comment" : "",
    "taskPriorities" : {
      "taskrepository.tsk#1407153522080" : 0.5,
      "taskrepository.tsk#1407153536219" : 0.5,
      "taskrepository.tsk#1402488486725" : 0.5,
      "taskrepository.tsk#1225112227903" : 0.5
    },
    "characteristics" : [ ],
    "roleSet" : 1410440904638
  }, {
    "id" : 1222973294444,
    "name" : "Keeper",
    "comment" : "",
    "taskPriorities" : {
      "taskrepository.tsk#1407153522080" : 0.5,
      "taskrepository.tsk#1407153536219" : 0.5,
      "taskrepository.tsk#1225112227903" : 0.5,
      "taskrepository.tsk#1402488486725" : 0.5
    },
    "characteristics" : [ ],
    "roleSet" : 1410440904638
  }, {
    "id" : 1222973295555,
    "name" : "AttackSupporter",
    "comment" : "",
    "taskPriorities" : {
      "taskrepository.tsk#1407153522080" : 0.5,
      "taskrepository.tsk#1407153536219" : 0.5,
      "taskrepository.tsk#1225112227903" : 0.5,
      "taskrepository.tsk#1402488486725" : 0.5
    },
    "characteristics" : [ ],
    "roleSet" : 1410440904638
  }, {
    "id" : 1222973296666,
    "name" : "Supporter",
    "comment" : "",
    "taskPriorities" : {
      "taskrepository.tsk#1407153522080" : 0.5,
      "taskrepository.tsk#1407153536219" : 0.5,
      "taskrepository.tsk#1225112227903" : 0.5,
      "taskrepository.tsk#1402488486725" : 0.5
    },
    "characteristics" : [ ],
    "roleSet" : 1410440904638
  } ]
}