{
  "comment": "",
  "defaultPriority": 0.5,
  "defaultRoleSet": true,
  "id": 1410440904638,
  "name": "RolesetTA",
  "relativeDirectory": "",
  "roles": [
    {
      "characteristics": [],
      "comment": "",
      "id": 1222973291111,
      "name": "Attacker",
      "roleSet": 1410440904638,
      "taskPriorities": {
        "taskrepository.tsk#1225112227903": 0.5,
        "taskrepository.tsk#1402488486725": 0.5,
        "taskrepository.tsk#1407153522080": 0.6,
        "taskrepository.tsk#1407153536219": 0.5
      }
    },
    {
      "characteristics": [],
      "comment": "",
      "id": 1222973292222,
      "name": "Defender",
      "roleSet": 1410440904638,
      "taskPriorities": {
        "taskrepository.tsk#1625610762033": 1.0,
        "taskrepository.tsk#1625610785404": 0.0
      }
    },
    {
      "characteristics": [],
      "comment": "",
      "id": 1222973293333,
      "name": "DefendSupporter",
      "roleSet": 1410440904638,
      "taskPriorities": {
        "taskrepository.tsk#1225112227903": 0.5,
        "taskrepository.tsk#1402488486725": 0.5,
        "taskrepository.tsk#1407153522080": 0.5,
        "taskrepository.tsk#1407153536219": 0.5
      }
    },
    {
      "characteristics": [],
      "comment": "",
      "id": 1222973294444,
      "name": "Keeper",
      "roleSet": 1410440904638,
      "taskPriorities": {
        "taskrepository.tsk#1225112227903": 0.5,
        "taskrepository.tsk#1402488486725": 0.5,
        "taskrepository.tsk#1407153522080": 0.5,
        "taskrepository.tsk#1407153536219": 0.5
      }
    },
    {
      "characteristics": [],
      "comment": "",
      "id": 1222973295555,
      "name": "AttackSupporter",
      "roleSet": 1410440904638,
      "taskPriorities": {
        "taskrepository.tsk#1225112227903": 0.5,
        "taskrepository.tsk#1402488486725": 0.5,
        "taskrepository.tsk#1407153522080": 0.5,
        "taskrepository.tsk#1407153536219": 0.5
      }
    },
    {
      "characteristics": [],
      "comment": "",
      "id": 1222973296666,
      "name": "Supporter",
      "roleSet": 1410440904638,
      "taskPriorities": {
        "taskrepository.tsk#1225112227903": 0.5,
        "taskrepository.tsk#1402488486725": 0.5,
        "taskrepository.tsk#1407153522080": 0.5,
        "taskrepository.tsk#1407153536219": 0.5
      }
    }
  ]
}
