{
  "comment": "",
  "defaultPriority": 0.5,
  "defaultRoleSet": true,
  "id": 1402500951766,
  "name": "Roleset",
  "relativeDirectory": "",
  "roles": [
    {
      "characteristics": [],
      "comment": "",
      "id": 1222973297047,
      "name": "Attacker",
      "roleSet": 1402500951766,
      "taskPriorities": {
        "taskrepository.tsk#1225112227903": 0.5
      }
    },
    {
      "characteristics": [],
      "comment": "",
      "id": 1222973297049,
      "name": "Defender",
      "roleSet": 1402500951766,
      "taskPriorities": {
        "taskrepository.tsk#1225112227903": 0.5
      }
    },
    {
      "characteristics": [],
      "comment": "",
      "id": 1222973297051,
      "name": "DefendSupporter",
      "roleSet": 1402500951766,
      "taskPriorities": {
        "taskrepository.tsk#1225112227903": 0.5
      }
    },
    {
      "characteristics": [],
      "comment": "",
      "id": 1222973297052,
      "name": "Keeper",
      "roleSet": 1402500951766,
      "taskPriorities": {
        "taskrepository.tsk#1225112227903": 0.5
      }
    },
    {
      "characteristics": [],
      "comment": "",
      "id": 1222973297054,
      "name": "AttackSupporter",
      "roleSet": 1402500951766,
      "taskPriorities": {
        "taskrepository.tsk#1225112227903": 0.5
      }
    },
    {
      "characteristics": [],
      "comment": "",
      "id": 1222973297056,
      "name": "Supporter",
      "roleSet": 1402500951766,
      "taskPriorities": {
        "taskrepository.tsk#1225112227903": 0.5
      }
    }
  ]
}