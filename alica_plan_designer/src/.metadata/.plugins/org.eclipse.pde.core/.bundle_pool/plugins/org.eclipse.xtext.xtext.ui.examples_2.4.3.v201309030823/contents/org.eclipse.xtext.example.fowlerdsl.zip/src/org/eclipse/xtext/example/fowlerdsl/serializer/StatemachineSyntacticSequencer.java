package org.eclipse.xtext.example.fowlerdsl.serializer;

public class StatemachineSyntacticSequencer extends AbstractStatemachineSyntacticSequencer {
}
