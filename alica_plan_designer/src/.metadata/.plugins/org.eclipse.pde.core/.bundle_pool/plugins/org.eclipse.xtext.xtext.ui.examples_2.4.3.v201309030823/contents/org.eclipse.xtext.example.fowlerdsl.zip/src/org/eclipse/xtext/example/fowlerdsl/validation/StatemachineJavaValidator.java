package org.eclipse.xtext.example.fowlerdsl.validation;
 

public class StatemachineJavaValidator extends AbstractStatemachineJavaValidator {

//	@Check
//	public void checkGreetingStartsWithCapital(Greeting greeting) {
//		if (!Character.isUpperCase(greeting.getName().charAt(0))) {
//			warning("Name should start with a capital", MyDslPackage.Literals.GREETING__NAME);
//		}
//	}

}
