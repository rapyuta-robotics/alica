package helper;

public class Circle implements Shape {
	public int diameter;

	public Circle(int diameter) {
		super();
		this.diameter = diameter;
	}
	
}
