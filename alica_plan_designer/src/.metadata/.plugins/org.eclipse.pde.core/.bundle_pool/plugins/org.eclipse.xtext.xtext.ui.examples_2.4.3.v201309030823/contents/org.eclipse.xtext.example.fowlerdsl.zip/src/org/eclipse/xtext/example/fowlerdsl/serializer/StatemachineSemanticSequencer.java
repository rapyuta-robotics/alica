package org.eclipse.xtext.example.fowlerdsl.serializer;

public class StatemachineSemanticSequencer extends AbstractStatemachineSemanticSequencer {
}
