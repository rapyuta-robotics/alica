package org.eclipse.xtext.example.domainmodel.serializer;

public class DomainmodelSemanticSequencer extends AbstractDomainmodelSemanticSequencer {
}
